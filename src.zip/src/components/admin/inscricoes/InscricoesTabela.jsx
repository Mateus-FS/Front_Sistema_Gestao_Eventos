import { useState } from "react";
import { useConfirmacao } from "../../../hooks/ui/useConfirmacao";
import { formatarData } from "../../../utils/formatacoes";
import { AlertaFeedback } from "../../AlertaFeedback";
import { SpinnerCentral } from "../../SpinnerCentral";
import { TabelaVazia } from "../../TabelaVazia";
import { ConfirmacaoModal } from "../ConfirmacaoModal";

const CLASSE_STATUS = {
  CONFIRMADA: "sge-badge-confirmada",
  CANCELADA: "sge-badge-cancelada",
  PENDENTE: "sge-badge-pendente",
};

const classeStatus = (status) =>
  CLASSE_STATUS[status] ?? "sge-badge-pendente";

export function InscricoesTabela({ dados, eventos = [] }) {
  const {
    lista,
    listaTotal,
    filtroEvento,
    setFiltroEvento,
    filtroUsuario,
    setFiltroUsuario,
    carregando,
    salvando,
    sucesso,
    setSucesso,
    erro,
    setErro,
    confirmar,
    cancelar,
    marcarPresenca,
  } = dados;

  const confirmacao = useConfirmacao();
  const [tipoAcao, setTipoAcao] = useState(null);

  const limparConfirmacao = () => {
    confirmacao.cancelar();
    setTipoAcao(null);
  };

  const abrirConfirmacao = (tipo, inscricao) => {
    setTipoAcao(tipo);

    const mensagem =
      tipo === "confirmar"
        ? `Confirmar inscrição de "${inscricao.usuarioNome}"?`
        : `Excluir inscrição de "${inscricao.usuarioNome}"?`;

    confirmacao.confirmar(inscricao.id, mensagem);
  };

  const handleConfirmarAcao = async () => {
    const ok =
      tipoAcao === "confirmar"
        ? await confirmar(confirmacao.id)
        : await cancelar(confirmacao.id);

    if (ok) limparConfirmacao();
  };

  const handleAlternarPresenca = (inscricao) => {
    marcarPresenca(inscricao.id, !inscricao.presente);
  };

  const tituloModal =
    tipoAcao === "confirmar" ? "Confirmar inscrição" : "Excluir inscrição";

  const textoBotaoModal = tipoAcao === "confirmar" ? "Confirmar" : "Excluir";

  const varianteModal = tipoAcao === "confirmar" ? "success" : "danger";

  const totalExibido = lista.length;
  const totalGeral = listaTotal?.length ?? totalExibido;
  const contadorTitulo =
    totalExibido === totalGeral
      ? `Inscrições (${totalExibido})`
      : `Inscrições (${totalExibido} de ${totalGeral})`;

  return (
    <>
      <AlertaFeedback
        sucesso={sucesso}
        erro={erro}
        onFecharSucesso={() => setSucesso("")}
        onFecharErro={() => setErro("")}
      />

      <div className="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <h6 className="fw-bold text-body-emphasis mb-0">
          <i className="bi bi-bookmark-check me-2 text-primary" aria-hidden="true" />
          {contadorTitulo}
        </h6>
        <div className="d-flex gap-2 flex-wrap">
          <select
            id="filtro-evento-inscricao"
            className="form-select form-select-sm sge-input"
            style={{ width: "auto", minWidth: 180 }}
            value={filtroEvento}
            onChange={(evento) => setFiltroEvento(evento.target.value)}
            disabled={carregando || salvando}
            aria-label="Filtrar por evento"
          >
            <option value="">Todos os eventos</option>
            {eventos.map((evento) => (
              <option key={evento.id} value={String(evento.id)}>
                {evento.titulo}
              </option>
            ))}
          </select>
          <input
            id="filtro-usuario-inscricao"
            type="search"
            className="form-control form-control-sm sge-input"
            style={{ width: 180 }}
            placeholder="Buscar usuário..."
            value={filtroUsuario}
            onChange={(evento) => setFiltroUsuario(evento.target.value)}
            disabled={carregando || salvando}
            aria-label="Buscar usuário"
          />
        </div>
      </div>

      {carregando ? (
        <SpinnerCentral />
      ) : lista.length === 0 ? (
        <TabelaVazia
          icone="bi-bookmark-x"
          texto="Nenhuma inscrição encontrada."
        />
      ) : (
        <div className="table-responsive">
          <table className="table table-hover align-middle small">
            <thead className="table-light">
              <tr>
                <th scope="col">Usuário</th>
                <th scope="col">Evento</th>
                <th scope="col">Status</th>
                <th scope="col">Presente</th>
                <th scope="col">Data</th>
                <th scope="col" className="text-end">
                  Ações
                </th>
              </tr>
            </thead>
            <tbody>
              {lista.map((inscricao) => (
                <tr key={inscricao.id}>
                  <td className="fw-semibold">{inscricao.usuarioNome}</td>
                  <td className="text-body-secondary">{inscricao.eventoNome}</td>
                  <td>
                    <span
                      className={`sge-badge-status ${classeStatus(inscricao.status)}`}
                    >
                      {inscricao.status}
                    </span>
                  </td>
                  <td>
                    <button
                      type="button"
                      className={`btn btn-sm ${
                        inscricao.presente
                          ? "btn-success"
                          : "btn-outline-secondary"
                      }`}
                      title={
                        inscricao.presente
                          ? "Desmarcar presença"
                          : "Marcar presença"
                      }
                      aria-label={
                        inscricao.presente
                          ? `Desmarcar presença de ${inscricao.usuarioNome}`
                          : `Marcar presença de ${inscricao.usuarioNome}`
                      }
                      onClick={() => handleAlternarPresenca(inscricao)}
                      disabled={salvando}
                      style={{ minWidth: 34, padding: "2px 8px" }}
                    >
                      <i
                        className={`bi ${
                          inscricao.presente ? "bi-check2-circle" : "bi-circle"
                        }`}
                        aria-hidden="true"
                      />
                    </button>
                  </td>
                  <td className="text-body-secondary">
                    {formatarData(inscricao.dataInscricao)}
                  </td>
                  <td className="text-end">
                    <div className="d-flex gap-1 justify-content-end">
                      {inscricao.status !== "CONFIRMADA" && (
                        <button
                          type="button"
                          className="btn btn-outline-success btn-sm"
                          title="Confirmar"
                          aria-label={`Confirmar inscrição de ${inscricao.usuarioNome}`}
                          onClick={() =>
                            abrirConfirmacao("confirmar", inscricao)
                          }
                          disabled={salvando}
                        >
                          <i className="bi bi-check-lg" aria-hidden="true" />
                        </button>
                      )}
                      {inscricao.status !== "CANCELADA" && (
                        <button
                          type="button"
                          className="btn btn-outline-danger btn-sm"
                          title="Excluir"
                          aria-label={`Excluir inscrição de ${inscricao.usuarioNome}`}
                          onClick={() =>
                            abrirConfirmacao("cancelar", inscricao)
                          }
                          disabled={salvando}
                        >
                          <i className="bi bi-trash3" aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <ConfirmacaoModal
        aberto={confirmacao.aberto}
        titulo={tituloModal}
        mensagem={confirmacao.mensagem}
        textoBotao={textoBotaoModal}
        variante={varianteModal}
        onConfirmar={handleConfirmarAcao}
        onCancelar={limparConfirmacao}
        carregando={salvando}
      />
    </>
  );
}