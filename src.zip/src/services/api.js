const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8080";

export const setToken = (token) => localStorage.setItem("sge_token", token);

export const getToken = () => localStorage.getItem("sge_token");

export const removeToken = () => localStorage.removeItem("sge_token");

const authHeaders = () => ({
  "Content-Type": "application/json",
  Authorization: `Bearer ${getToken()}`,
});

export async function request(method, path, body) {
  const response = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: authHeaders(),
    body: body ? JSON.stringify(body) : undefined,
  });

  if (response.status === 401 || response.status === 403) {
    removeToken();
    window.location.href = "/login";
    return;
  }

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText || `Erro ${response.status}`);
  }

  if (response.status === 204) return null;

  return response.json();
}

export { BASE_URL };
