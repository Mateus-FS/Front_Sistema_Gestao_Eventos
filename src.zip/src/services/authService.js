import { BASE_URL } from "./api";

export const authService = {
  login: async (email, senha) => {
    const response = await fetch(`${BASE_URL}/api/sge/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, senha }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || "Erro ao realizar login");
    }

    return response.json();
  },
};
